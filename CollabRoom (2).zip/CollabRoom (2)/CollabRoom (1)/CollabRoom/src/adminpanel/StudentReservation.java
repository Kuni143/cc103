/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package adminpanel;

/**
 *
 * @author Rayjen Mendoza
 */
public class StudentReservation {
    private int id;
    private String studentNumber, reservedBy, userType, program, date, time, purpose, roomNumber, status;
    private int numberOfMembers;

    public StudentReservation(int id, String studentNumber, String reservedBy, String userType, String program,
                              String date, String time, int numberOfMembers, String purpose,
                              String roomNumber, String status) {
        this.id = id;
        this.studentNumber = studentNumber;
        this.reservedBy = reservedBy;
        this.userType = userType;
        this.program = program;
        this.date = date;
        this.time = time;
        this.numberOfMembers = numberOfMembers;
        this.purpose = purpose;
        this.roomNumber = roomNumber;
        this.status = status;
    }

    public int getId() { return id; }
    public String getStudentNumber() { return studentNumber; }
    public String getReservedBy() { return reservedBy; }
    public String getUserType() { return userType; }
    public String getProgram() { return program; }
    public String getDate() { return date; }
    public String getTime() { return time; }
    public int getNumberOfMembers() { return numberOfMembers; }
    public String getPurpose() { return purpose; }
    public String getRoomNumber() { return roomNumber; }
    public String getStatus() { return status; }
}
