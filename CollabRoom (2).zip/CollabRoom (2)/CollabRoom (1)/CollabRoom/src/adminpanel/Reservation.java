/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package adminpanel;

import javafx.beans.property.SimpleStringProperty;

/**
 *
 * @author Rayjen Mendoza
 */
public class Reservation {
    private final SimpleStringProperty roomNumber;
    private final SimpleStringProperty date;
    private final SimpleStringProperty time;

    public Reservation(String roomNumber, String date, String time) {
        this.roomNumber = new SimpleStringProperty(roomNumber);
        this.date = new SimpleStringProperty(date);
        this.time = new SimpleStringProperty(time);
    }

    public String getRoomNumber() {
        return roomNumber.get();
    }

    public String getDate() {
        return date.get();
    }

    public String getTime() {
        return time.get();
    }
}
