package adminpanel;

import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;
import javafx.collections.*;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.Alert.AlertType;

public class ReservationPanelController implements Initializable {

    @FXML private TableView<StudentReservation> reservationTable;
    @FXML private TableColumn<StudentReservation, String> studentNumCol;
    @FXML private TableColumn<StudentReservation, String> reservedByCol;
    @FXML private TableColumn<StudentReservation, String> qcianUserCol;
    @FXML private TableColumn<StudentReservation, String> programCol;
    @FXML private TableColumn<StudentReservation, String> dateCol;
    @FXML private TableColumn<StudentReservation, String> timeCol;
    @FXML private TableColumn<StudentReservation, Integer> numOfMemCol;
    @FXML private TableColumn<StudentReservation, String> purposeCol;
    @FXML private TableColumn<StudentReservation, String> roomNumberCol;
    @FXML private TableColumn<StudentReservation, String> statusCol;

    @FXML private ChoiceBox<String> roomChoiceBox;
    @FXML private Button confirmButton;
    @FXML private Button denyButton;

    private ObservableList<StudentReservation> reservationList = FXCollections.observableArrayList();

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Set column mappings
        studentNumCol.setCellValueFactory(new PropertyValueFactory<>("studentNumber"));
        reservedByCol.setCellValueFactory(new PropertyValueFactory<>("reservedBy"));
        qcianUserCol.setCellValueFactory(new PropertyValueFactory<>("userType"));
        programCol.setCellValueFactory(new PropertyValueFactory<>("program"));
        dateCol.setCellValueFactory(new PropertyValueFactory<>("date"));
        timeCol.setCellValueFactory(new PropertyValueFactory<>("time"));
        numOfMemCol.setCellValueFactory(new PropertyValueFactory<>("numberOfMembers"));
        purposeCol.setCellValueFactory(new PropertyValueFactory<>("purpose"));
        roomNumberCol.setCellValueFactory(new PropertyValueFactory<>("roomNumber"));
        statusCol.setCellValueFactory(new PropertyValueFactory<>("status"));

        // Room numbers
        roomChoiceBox.setItems(FXCollections.observableArrayList("Room 001", "Room 002", "Room 003", "Room 004"));

        loadReservations();

        confirmButton.setOnAction(e -> handleConfirm());
        denyButton.setOnAction(e -> handleDeny());
    }

    private void loadReservations() {
        reservationList.clear();
        String query = "SELECT * FROM reservationtbl";

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/collab_room_scheduler", "root", "");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                reservationList.add(new StudentReservation(
                    rs.getInt("id"),
                    rs.getString("student_number"),
                    rs.getString("fullname"),
                    rs.getString("user_type"),
                    rs.getString("program"),
                    rs.getString("date"),
                    rs.getString("time"),
                    rs.getInt("number_of_members"),
                    rs.getString("purpose"),
                    rs.getString("room_number"),
                    rs.getString("status")
                ));
            }

            reservationTable.setItems(reservationList);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void handleConfirm() {
        StudentReservation selected = reservationTable.getSelectionModel().getSelectedItem();
        String selectedRoom = roomChoiceBox.getValue();

        if (selected == null || selectedRoom == null) {
            showAlert(AlertType.WARNING, "Selection Required", "Please select a reservation and a room.");
            return;
        }

        String updateQuery = "UPDATE reservationtbl SET status = ?, room_number = ? WHERE id = ?";

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/collab_room_scheduler", "root", "");
             PreparedStatement pstmt = conn.prepareStatement(updateQuery)) {

            pstmt.setString(1, "confirmed");
            pstmt.setString(2, selectedRoom);
            pstmt.setInt(3, selected.getId());
            pstmt.executeUpdate();

            showAlert(AlertType.INFORMATION, "Success", "Reservation confirmed!");
            loadReservations();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void handleDeny() {
        StudentReservation selected = reservationTable.getSelectionModel().getSelectedItem();

        if (selected == null) {
            showAlert(AlertType.WARNING, "Selection Required", "Please select a reservation to deny.");
            return;
        }

        String updateQuery = "UPDATE reservationtbl SET status = ? WHERE id = ?";

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/collab_room_scheduler", "root", "");
             PreparedStatement pstmt = conn.prepareStatement(updateQuery)) {

            pstmt.setString(1, "denied");
            pstmt.setInt(2, selected.getId());
            pstmt.executeUpdate();

            showAlert(AlertType.INFORMATION, "Denied", "Reservation denied.");
            loadReservations();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void showAlert(AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
