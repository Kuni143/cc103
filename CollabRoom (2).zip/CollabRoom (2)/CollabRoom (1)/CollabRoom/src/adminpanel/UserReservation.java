package adminpanel;

public class UserReservation {
    private String studentNumber;
    private String reservedBy;
    private String dateSched;
    private String time;
    private int groupSize;
    private String status;
    private String createdAt;

    public UserReservation(String studentNumber, String reservedBy, String dateSched, String time, int groupSize, String status, String createdAt) {
        this.studentNumber = studentNumber;
        this.reservedBy = reservedBy;
        this.dateSched = dateSched;
        this.time = time;
        this.groupSize = groupSize;
        this.status = status;
        this.createdAt = createdAt;
    }

    public String getStudentNumber() { return studentNumber; }
    public String getReservedBy() { return reservedBy; }
    public String getDateSched() { return dateSched; }
    public String getTime() { return time; }
    public int getGroupSize() { return groupSize; }
    public String getStatus() { return status; }
    public String getCreatedAt() { return createdAt; }
}
