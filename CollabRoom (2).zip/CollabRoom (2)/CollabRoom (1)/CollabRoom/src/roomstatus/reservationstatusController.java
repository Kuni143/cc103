package roomstatus;

import javafx.scene.image.Image;
import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;

public class reservationstatusController implements Initializable {

    // Database credentials
    private static final String DB_URL = "jdbc:mysql://localhost:3306/collab_room_scheduler";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";

    @FXML private Label statusLabel;
    @FXML private ImageView statusIcon;
    @FXML private Label roomLabel;
    @FXML private Label messageLabel;
    @FXML private Button cancelButton;

    @FXML private Label status001Label;
    @FXML private Label status002Label;
    @FXML private Label status003Label;
    @FXML private Label status004Label;

    private String studentNumber;

    public void setReservationDetails(String status, String room, String studentNum) {
        this.studentNumber = studentNum;
        statusLabel.setText(capitalizeStatus(status));

        // Enable wrapping
        messageLabel.setWrapText(true);
        messageLabel.setPrefWidth(250);
        messageLabel.setAlignment(Pos.CENTER);
        messageLabel.setTextAlignment(TextAlignment.CENTER);

        switch (status.toLowerCase()) {
            case "on-hold":
                statusIcon.setImage(new Image("/roomstatus/On-Hold.png"));
                messageLabel.setText("Waiting for admin to confirm");
                roomLabel.setText("Room Number");
                cancelButton.setDisable(false);
                break;
            case "confirmed":
                statusIcon.setImage(new Image("/roomstatus/check.png"));
                messageLabel.setText("You have been successfully\n         reserved");
                roomLabel.setText(room);
                cancelButton.setDisable(true);
                break;
            case "denied":
                statusIcon.setImage(new Image("/roomstatus/x.png"));
                messageLabel.setText("We are sorry, your reservation has been denied");
                roomLabel.setText(room);
                cancelButton.setDisable(true);
                break;
            default:
                messageLabel.setText("Unknown status");
                roomLabel.setText("");
                cancelButton.setDisable(true);
                break;
        }
    }

    private String capitalizeStatus(String status) {
        if (status == null || status.isEmpty()) return status;

        String[] parts = status.split("-");
        StringBuilder formatted = new StringBuilder();

        for (int i = 0; i < parts.length; i++) {
            String word = parts[i];
            if (!word.isEmpty()) {
                formatted.append(Character.toUpperCase(word.charAt(0)))
                         .append(word.substring(1).toLowerCase());
            }
            if (i < parts.length - 1) {
                formatted.append("-");
            }
        }

        return formatted.toString();
    }

    @FXML
    private void handleCancel(ActionEvent event) {
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String sql = "DELETE FROM reservationtbl WHERE student_number = ? AND status = 'on-hold'";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, studentNumber);

            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Canceled");
                alert.setContentText("Your reservation has been canceled.");
                alert.showAndWait();

                cancelButton.setDisable(true);
                statusLabel.setText("Canceled");
                messageLabel.setText("Your reservation has been canceled.");
                statusIcon.setImage(new Image("/roomstatus/ekis.png"));
            }

            stmt.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleBack(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("searchstatus.fxml"));
            Parent root = loader.load();

            Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void loadRoomStatuses() {
        String sql = "SELECT room_id, status FROM roomstatustbl";

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                String roomId = rs.getString("room_id");
                String status = rs.getString("status");
                String displayStatus = capitalizeStatus(status);
                Label labelToUpdate = null;

                switch (roomId) {
                    case "001":
                        labelToUpdate = status001Label;
                        break;
                    case "002":
                        labelToUpdate = status002Label;
                        break;
                    case "003":
                        labelToUpdate = status003Label;
                        break;
                    case "004":
                        labelToUpdate = status004Label;
                        break;
                }

                if (labelToUpdate != null) {
                    labelToUpdate.setText(displayStatus);

                    switch (status.toLowerCase()) {
                        case "available":
                            labelToUpdate.setTextFill(Color.web("#45E363"));
                            break;
                        case "reserved":
                            labelToUpdate.setTextFill(Color.web("Gray"));
                            break;
                        case "occupied":
                            labelToUpdate.setTextFill(Color.web("#E6E6EC"));
                            break;
                        default:
                            labelToUpdate.setTextFill(Color.web("#45E363"));
                            break;
                    }
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        loadRoomStatuses();
    }
}
