package roomstatus;

import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class searchstatusController {

    @FXML private TextField studentNumberField;

    @FXML
    private void handleSearch(ActionEvent event) {
        String studentNumber = studentNumberField.getText().trim();

        if (studentNumber.isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Missing Input");
            alert.setContentText("Please enter a student number.");
            alert.showAndWait();
            return;
        }

        try {
            Connection conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/collab_room_scheduler", "root", ""
            );

            String sql = "SELECT * FROM reservationtbl WHERE student_number = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, studentNumber);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("reservationstatus.fxml"));
                Parent root = loader.load();

                reservationstatusController controller = loader.getController();
                controller.setReservationDetails(
                    rs.getString("status"),
                    rs.getString("room_number"),
                    rs.getString("student_number")
                );

                Stage stage = (Stage) studentNumberField.getScene().getWindow();
                stage.setScene(new Scene(root));
            } else {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Not Found");
                alert.setContentText("No reservation found for student number: " + studentNumber);
                alert.showAndWait();
            }

            rs.close();
            stmt.close();
            conn.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
        @FXML
        private void handleBack(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/collabroom/FXMLDocument.fxml"));
            Parent root = loader.load();
        
            Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
