package reservation;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ToggleGroup;
import javafx.stage.Stage;

public class FXMLDocumentController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private ToggleGroup group1;

    @FXML
    private ChoiceBox<?> myChoiceBox;

    @FXML
    private ChoiceBox<?> myChoiceBox2;

    @FXML
    private ChoiceBox<?> myChoiceBox3;

    @FXML
    void initialize() {
        assert group1 != null : "fx:id=\"group1\" was not injected: check your FXML file 'FXMLDocument.fxml'.";
        assert myChoiceBox != null : "fx:id=\"myChoiceBox\" was not injected: check your FXML file 'FXMLDocument.fxml'.";
        assert myChoiceBox2 != null : "fx:id=\"myChoiceBox2\" was not injected: check your FXML file 'FXMLDocument.fxml'.";
        assert myChoiceBox3 != null : "fx:id=\"myChoiceBox3\" was not injected: check your FXML file 'FXMLDocument.fxml'.";

    }
    
    @FXML
    private void handlebackbtn (ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/collabroom/FXMLDocument.fxml"));
            Parent reservationRoot = loader.load();
            
            Stage dashboardStage = new Stage();
            dashboardStage.setScene(new Scene(reservationRoot));
            dashboardStage.setTitle("Collaboration Room");
            dashboardStage.show();
            
            Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            currentStage.close();
        } catch (IOException e) {
            e.printStackTrace();
        
    }
        
    }
}
