package adminpanel;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.input.MouseEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.control.PasswordField;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;


public class AdminPanelController {

    @FXML
    private AnchorPane
            dashboardContent;

    @FXML
    private AnchorPane usersContent;

    @FXML
    private BorderPane dashboardRoot;

    @FXML
    private AnchorPane adminContent;
    
    @FXML
    private AnchorPane roomsContent;
    
    @FXML
    private AnchorPane reservationContent;
    
    @FXML
    private AnchorPane accountContent;
    
    @FXML
    private AnchorPane settingsContent;
        
    @FXML
    private Button passwordEnterButton;
    
    @FXML
    private Button handleChangePassword;
    
    @FXML
    private PasswordField newPasswordField;
    
    @FXML
    private PasswordField confirmPasswordField;
    
    @FXML
    private CheckBox showPasswordBox;
    
    @FXML
    private TextField visiblePasswordField;
    
    @FXML
    private TextField visiblePasswordField1;
    
    @FXML
    private TextField passwordField;
    
    private String savedPassword = "admin1234";
    
    @FXML
    private Button logoutButton;
    
    @FXML
    private TextField adminPasswordField;
    
    @FXML
    private TextField adminNameField;

    
    


    @FXML
    private void handleDashboardClick (MouseEvent event){
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("DashboardPanel.fxml"));
            Parent dashboardContent = loader.load();


            adminContent.getChildren().setAll(dashboardContent);
            AnchorPane.setTopAnchor(dashboardContent, 0.0);
            AnchorPane.setBottomAnchor(dashboardContent, 0.0);
            AnchorPane.setLeftAnchor(dashboardContent, 0.0);
            AnchorPane.setRightAnchor(dashboardContent, 0.0);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

        @FXML
        private void handleUsersClick (MouseEvent event){
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("UsersPanel.fxml"));
                Parent usersContent = loader.load();

                adminContent.getChildren().setAll(usersContent);
                AnchorPane.setTopAnchor(usersContent, 0.0);
                AnchorPane.setBottomAnchor(usersContent, 0.0);
                AnchorPane.setLeftAnchor(usersContent, 0.0);
                AnchorPane.setRightAnchor(usersContent, 0.0);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        
        
        
        @FXML
        private void handleRoomsClick (MouseEvent event){
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("RoomsPanel.fxml"));
                Parent roomsContent = loader.load();

                adminContent.getChildren().setAll(roomsContent);
                AnchorPane.setTopAnchor(roomsContent, 0.0);
                AnchorPane.setBottomAnchor(roomsContent, 0.0);
                AnchorPane.setLeftAnchor(roomsContent, 0.0);
                AnchorPane.setRightAnchor(roomsContent, 0.0);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        
        
        @FXML
        private void handleReservationClick (MouseEvent event) {
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource ("ReservationPanel.fxml"));
                Parent reservationContent = loader.load();
                
                adminContent.getChildren().setAll(reservationContent);
                AnchorPane.setTopAnchor(reservationContent, 0.0);
                AnchorPane.setBottomAnchor(reservationContent, 0.0);
                AnchorPane.setLeftAnchor(reservationContent, 0.0);
                AnchorPane.setRightAnchor(reservationContent, 0.0);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        
        
        @FXML
        private void handleSettingsClick (MouseEvent event) {
            try {
                
                FXMLLoader loader = new FXMLLoader(getClass().getResource("SettingsPanel.fxml"));
                Parent settingsContent = loader.load();
                
                adminContent.getChildren().setAll(settingsContent);
                AnchorPane.setTopAnchor(settingsContent, 0.0);
                AnchorPane.setBottomAnchor(settingsContent, 0.0);
                AnchorPane.setLeftAnchor(settingsContent, 0.0);
                AnchorPane.setRightAnchor(settingsContent, 0.0);
            } catch (Exception e) {
                e.printStackTrace ();
            }
        }
   
       
        
   
@FXML
private void passwordEnterClick(ActionEvent event) {
    String inputPassword = passwordField.getText();
   
    if (PasswordManager.checkPassword(inputPassword)) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("AccountPanel.fxml"));
            Parent accountContent = loader.load();

            adminContent.getChildren().setAll(accountContent);
            AnchorPane.setTopAnchor(accountContent, 0.0);
            AnchorPane.setBottomAnchor(accountContent, 0.0);
            AnchorPane.setLeftAnchor(accountContent, 0.0);
            AnchorPane.setRightAnchor(accountContent, 0.0);

        } catch (IOException e) {
            e.printStackTrace();
        }
    } else {
        System.out.println("Incorrect password. Try again.");
    }
}

     
        
        @FXML
        private void handleChangePassword(ActionEvent event) {
            String newPass = visiblePasswordField.getText().trim();
            String confirmPass = visiblePasswordField1.getText().trim();
            
            System.out.println("New: '" + newPass + "'");
            System.out.println("Confirm: '" + confirmPass + "'");
            
            if (newPass.equals(confirmPass) && !newPass.isEmpty()) {
                PasswordManager.setSavedPassword(newPass);
                System.out.println("Password changed successfully.");
            } else {
                System.out.println("Passwords do not match.");
            }
            
            
        }
        
        
        @FXML
        private void handleLogOutButton(ActionEvent event) {
            Stage stage = (Stage)logoutButton.getScene().getWindow();
            stage.close();
        }
        
        
        
}
       


  


