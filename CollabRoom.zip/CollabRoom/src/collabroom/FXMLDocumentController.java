/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXML2.java to edit this template
 */
package collabroom;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;




/**
 *
 * @author ASUS
 */
public class FXMLDocumentController implements Initializable {    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
    
    private Button adminButton;
    private Button reservationButton;
    private Button reservationBackButton;

    
    @FXML
    private void handleAdminClick(ActionEvent event) {
             try {
             FXMLLoader loader = new FXMLLoader(getClass().getResource("/adminpanel/AdminLogIn.fxml"));
             Parent adminLoginRoot = loader.load();

             Stage dashboardStage = new Stage();
             dashboardStage.setScene(new Scene(adminLoginRoot));
             dashboardStage.setTitle("Admin Panel");
             dashboardStage.show();

            Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            currentStage.close();

            } catch (IOException e) {
            e.printStackTrace();
            }
        }

    
    @FXML
    private void handleReservationClick(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/reservation/FXMLDocument.fxml"));
            Parent reservationRoot = loader.load();
            
            Stage dashboardStage = new Stage();
            dashboardStage.setScene(new Scene(reservationRoot));
            dashboardStage.setTitle("Reservation Form");
            dashboardStage.show();
            
            Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            currentStage.close();
        } catch (IOException e) {
            e.printStackTrace();
        
    }
    }
    
    
    
    @FXML
    private void handleReservationBackClick(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/collabroom/FXMLDocument.fxml"));
            Parent collabRoomRoot = loader.load();
            
            Stage dashboardStage = new Stage();
            dashboardStage.setScene(new Scene(collabRoomRoot));
            dashboardStage.setTitle("Collab Room");
            dashboardStage.show();
            
            Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            currentStage.close();
        } catch (IOException e) {
            e.printStackTrace();
        
    }
    }
    
    
}
   
