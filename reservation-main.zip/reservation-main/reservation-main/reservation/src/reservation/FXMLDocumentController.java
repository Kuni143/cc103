package reservation;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.scene.control.ChoiceBox;

public class FXMLDocumentController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private ChoiceBox<String> myChoiceBox;  // Link this to your FXML fx:id
    
    @FXML
    private ChoiceBox<String> myChoiceBox2;
    
    @FXML
    private ChoiceBox<String> myChoiceBox3;

    @FXML
    void initialize() {
        myChoiceBox.getItems().addAll("BS Information Technology", "BS Industrial Engineering", "BS Electronic Engineering", "BS Entrepreneurship", "BS Accountancy", "BS Information System", "BS Early Childhood Education", "BS Computer Science");
        myChoiceBox.setValue("Select"); // Default selection
        
        myChoiceBox2.getItems().addAll("5", "6", "7", "8", "9", "10");
        myChoiceBox2.setValue("Select"); // Default selection
        
        myChoiceBox3.getItems().addAll("8:00AM - 9:00AM", "9:00AM - 10:00AM", "10:00AM - 11:00AM", "11:00AM - 12:00PM", "12:00PM - 1:00PM", "1:00PM - 2:00PM", "2:00PM - 3:00PM", "3:00PM - 4:00PM", "4:00PM - 5:00PM");
        myChoiceBox3.setValue("Select"); // Default selection
    }
    
}
